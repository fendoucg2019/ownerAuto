# -*- encoding=utf8 -*-
__author__ = "Administrator"

from airtest.core.api import *
from poco.drivers.std import StdPoco
from poco.drivers.android.uiautomation import AndroidUiautomationPoco

# install("E:\\自动化\\guangdongmj-V3.7.6.0.0-3730-201903151442-18local-debug.apk")
# time.sleep(3)
# print('install app')
start_app('com.dashengzhangyou.pykf.lailaiguangdong')
# time.sleep(5)
from poco.drivers.std import StdPoco
poco = StdPoco()

from airtest.core.api import using
using('getGdcity.air')
from getGdCity import Gd
auto_setup(__file__)
poco("<Node | Tag = -1").child("<LayerColor | Tag = -1>")[1].child("Widget")[1].click()
# text('161461')
# text("123")text("dafa")
text("456456")


# poco("<Node | Tag = -1").child("<LayerColor | Tag = -1>")[1].child("Button").click()
# time.sleep(3)
# Gd.getGDcitylist()
# a=Gd.countGDcity()
# for i in range(a):
#     Gd.clickcity()
#     Gd.removecity()
    # poco("btn_yes_city").click()
    # poco("yes").click()
poco("<Node | Tag = -1").child("Button")[1]
